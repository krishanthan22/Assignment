package com.org.kris.bankgateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankgatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankgatewayApplication.class, args);
	}

}
