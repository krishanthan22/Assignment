package com.org.kris.bankgateway.controller;

import com.org.kris.bankgateway.domain.AccountData;
import com.org.kris.bankgateway.domain.AccountRequest;
import org.springframework.beans.factory.annotation.Autowired;


@RestController
public class BankAccountController {

    @GetMapping("/validateAccount")
    public AccountData validate(@RequestBody AccountRequest accountRequest) {
        System.out.println("accountRequest "+accountRequest.getSortCode());
        return new AccountData("test", true);
    }
}
