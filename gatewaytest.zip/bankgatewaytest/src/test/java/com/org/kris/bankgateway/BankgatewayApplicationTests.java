package com.org.kris.bankgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankgatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
